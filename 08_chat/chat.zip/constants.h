#ifndef CONSTANTS_H_
#define CONSTANTS_H_

#define FIFO_PATH "chat"
#define BUFF_SIZE 4096

#endif
