#ifndef CHAT_H_
#define CHAT_H_

void initialize();
int send(int fd);
int receive(int fd);

#endif
