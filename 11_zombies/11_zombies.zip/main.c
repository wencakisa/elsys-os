#include <unistd.h>
#include <pthread.h>

#include "ui.h"

#define EXIT_COMMAND              'q'
#define INIT_MINER_COMMAND        'm'
#define INIT_SOLDIER_COMMAND      's'
#define INIT_10X_SOLDIERS_COMMAND 'x'

#define GOLD_PER_ACTION 10
#define PRICE_PER_ENTITY 10
#define ZOMBIES_INIT_DISTANCE 5

pthread_mutex_t mutex;

long gold = 10;
long health = 10;

long zombies_count = 1;
long soldiers_count = 0;

void* miner(void* arg) {
    pthread_mutex_lock(&mutex);

    if (gold - PRICE_PER_ENTITY < 0) {
        print_fail("Not enough gold!");
        pthread_mutex_unlock(&mutex);
        return NULL;
    }

    print_msg("Miner created!");

    gold -= PRICE_PER_ENTITY;
    print_gold(gold);

    pthread_mutex_unlock(&mutex);

    while (1) {
        pthread_mutex_lock(&mutex);

        gold += GOLD_PER_ACTION;
        print_gold(gold);

        pthread_mutex_unlock(&mutex);

        sleep(1);
    }

    return NULL;
}

void* zombie(void* arg) {
    while (1) {
        for (size_t i = ZOMBIES_INIT_DISTANCE; i > 0; i--) {
            print_zombies(i, zombies_count);
            sleep(1);
        }

        pthread_mutex_lock(&mutex);

        if (zombies_count > soldiers_count) {
            health -= zombies_count - soldiers_count;
            print_health(health);

            print_fail("Zombie attack succeeded ;(!");

            if (health <= 0) {
                game_end(zombies_count);
                return NULL;
            }
        } else {
            print_succ("Zombie attack deflected! :)");
        }

        zombies_count *= 2;

        pthread_mutex_unlock(&mutex);
    }

    return NULL;
}

void* soldier(void* arg) {
    pthread_mutex_lock(&mutex);

    if (gold - PRICE_PER_ENTITY < 0) {
        print_fail("Not enough gold!");
        pthread_mutex_unlock(&mutex);
        return NULL;
    }

    print_msg("Soldier created!");

    gold -= PRICE_PER_ENTITY;
    soldiers_count++;

    print_gold(gold);
    print_soldiers(soldiers_count);

    pthread_mutex_unlock(&mutex);

    return NULL;
}

int main() {
	init();

    print_gold(gold);
    print_soldiers(soldiers_count);
    print_health(health);

    pthread_t zombies_thread;
    pthread_t miners_thread;
    pthread_t soldiers_thread;

    pthread_create(&zombies_thread, NULL, zombie, NULL);

    while (1) {
		int ch = get_input();

        switch(ch) {
            case INIT_MINER_COMMAND:
                pthread_create(&miners_thread, NULL, miner, NULL);
                break;
            case INIT_SOLDIER_COMMAND:
                pthread_create(&soldiers_thread, NULL, soldier, NULL);
                break;
            case INIT_10X_SOLDIERS_COMMAND:
                print_msg("10 x soldiers not really created yet!");
                break;
			case EXIT_COMMAND:
				game_end(zombies_count);
				break;
		}
    }
}
