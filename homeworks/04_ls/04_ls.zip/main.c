#include "ls.h"

int main(int argc, char const *argv[]) {
    ls(argc - 1, argv + 1);

    return 0;
}
